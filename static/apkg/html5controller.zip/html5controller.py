# -*- coding: utf-8 -*-
# HTML5 Video Controller: an Anki addon loads js to control playback rate.
# GitHub: https://github.com/luminousspice/anki-addons/
#
# Copyright: 2016 Luminous Spice <luminous.spice@gmail.com>
# License: GNU AGPL, version 3 or later; http://www.gnu.org/copyleft/agpl.html

from anki.hooks import addHook
from aqt import mw
import anki.js


html5controller = u"""
var video = document.getElementById("video");
var playbackRate  = document.getElementById("playbackRate");

$(function() {
    $("#slider").slider({
        value: 1.0,
        min: 0.3,
        max: 3.0,
        step: 0.1,
        slide: function(event, ui) {
            video.playbackRate = ui.value;
            playbackRate.innerHTML = ui.value.toFixed(1) + " 倍速";
        }
    });
    $("#playbackRate").val($("#slider").slider("value"));
});
"""


def loadhtml5controller():
    """Load js to control playback rate of #video through #slider."""
    mw.web.eval(anki.js.ui)
    mw.web.eval(html5controller)

addHook("showQuestion", loadhtml5controller)
addHook("showAnswer", loadhtml5controller)
